<?php

namespace App\Services;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Processor\IntrospectionProcessor;
use Monolog\Processor\WebProcessor;
use Monolog\Formatter\JsonFormatter;

class LoggerService
{
    private $logger;

    public function __construct()
    {
        $this->logger = new Logger('api');

        // Handler para todos los logs
        $allHandler = new RotatingFileHandler(__DIR__ . '/../../logs/all.log', 0, Logger::DEBUG, true, 0664);
        $allHandler->setFormatter(new JsonFormatter());

        // Handler solo para errores
        $errorHandler = new StreamHandler(__DIR__ . '/../../logs/error.log', Logger::ERROR);
        $errorHandler->setFormatter(new JsonFormatter());

        $this->logger->pushHandler($allHandler);
        $this->logger->pushHandler($errorHandler);

        // Añadir procesadores para más contexto
        $this->logger->pushProcessor(new IntrospectionProcessor());
        $this->logger->pushProcessor(new WebProcessor());
        $this->logger->pushProcessor(function ($record) {
            $record['extra']['memory_usage'] = memory_get_usage(true);
            return $record;
        });
    }

    public function getLogger()
    {
        return $this->logger;
    }
}
