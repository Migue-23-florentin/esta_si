<?php

namespace App\Controllers;

use PDO;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use PDOException;
use Monolog\Logger;
use App\Helpers\ResponseHelper;

class AuthController
{
    private $db;
    private $logger;
    private $config;

    public function __construct(PDO $db, Logger $logger, array $config)
    {
        $this->db = $db;
        $this->logger = $logger;
        $this->config = $config;

    }

    public function login(Request $request, Response $response): Response
    {
        $params = $request->getParsedBody();
        $username = $params['username'] ?? '';
        $password = $params['password'] ?? '';

        $responseHelper = new ResponseHelper($response);
        
        $this->logger->info('Intento de inicio de sesión', [
            'username' => $request->getParsedBody()['username'] ?? 'unknown'
        ]);

        try {
            $stmt = $this->db->prepare("
                SELECT id, id_person, clave
                FROM inscripcion_alumnos.usuario
                WHERE cedula = :cedula AND active = 1
            ");

            $stmt->execute(['cedula' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // if ($user && password_verify($password, $user['clave'])) { // Si la contraseña tiene encriptado usar este condicionante
            if ($user && strcmp($password, $user['clave']) === 0) {
                $token = $this->generarToken($user['id'], $user['id_person']);
                $refreshToken = $this->generarRefreshToken($user['id'], $user['id_person']);


                $sql = "SELECT 
                            nombre, 
                            apellidos, 
                            public.country.name as nacionalidad, 
                            fechanac, 
                            sexo,
                            persons_estado_civil_type.name as estado_civil,
                            canthijos,
                            domicilio,
                            barrio,
                            public.city.name as ciudad,
                            public.distritos.name as departamento,
                            tel, 
                            email,
                            tel_celular,
                            tel_celular_2,
                            otro_celular_1,
                            otro_celular_2
                        FROM personas.persons  
                        LEFT JOIN personas.persons_estado_civil_type ON persons_estado_civil_type.id = persons.estado_civil
                        LEFT JOIN public.city ON public.city.id = personas.persons.city_id
                        LEFT JOIN public.distritos ON public.distritos.id = personas.persons.distrito_id
                        LEFT JOIN public.country ON public.country.code = personas.persons.nacionalidad
                        WHERE persons.id = :id";

                $stmt = $this->db->prepare($sql);
                $stmt->execute(['id' => $user['id_person']]);
                $perfil = $stmt->fetch(PDO::FETCH_ASSOC);

                $sql = "SELECT 
                            ve.id_especialidades,
                            ve.especialidad,
                            ve.area,
                            ve.familia,
                            ve.carga_horaria,
                            ia.fecha_inscripcion,
                            ei.descripcion as estado_inscripcion,
                            ia.observacion,
                            ia.aprobado
                        FROM inscripcion_alumnos.alumno al
                        JOIN inscripcion_alumnos.inscripcion_alumno ia ON ia.id_alumno = al.id_alumno
                        JOIN planificacion.planificacion pl ON ia.id_planificacion = pl.id_planificacion
                        JOIN planificacion.vista_especialidad ve ON ve.id_especialidades = pl.id_especialiadad
                        JOIN inscripcion_alumnos.estado_inscripcion ei ON ei.id = ia.estado_inscripcion
                        WHERE al.id_usuario = :id_alumno AND ei.descripcion = 'ACTIVO'";

                $stmt = $this->db->prepare($sql);
                $stmt->execute(['id_alumno' => $user['id']]);
                $cursos = $stmt->fetchAll(PDO::FETCH_ASSOC);

                $userData = [
                    'id' => $user['id'],
                    'id_person' => $user['id_person'],
                    'email' => $perfil['email'],
                    'nombre' => $perfil['nombre'],
                    'apellido' => $perfil['apellidos'],
                    'nacionalidad' => trim($perfil['nacionalidad']), 
                    'fechanac' => $perfil['fechanac'], 
                    'sexo' => $perfil['sexo'],
                    'estado_civil' => $perfil['estado_civil'],
                    'canthijos' => $perfil['canthijos'],
                    'domicilio' => $perfil['domicilio'],
                    'barrio' => $perfil['barrio'],
                    'ciudad' => trim($perfil['ciudad']),
                    'departamento' => $perfil['departamento'],
                    'tel' => $perfil['tel'], 
                    'email' => $perfil['email'],
                    'tel_celular' => $perfil['tel_celular'],
                    'tel_celular_2' => $perfil['tel_celular_2'],
                    'otro_celular_1' => $perfil['otro_celular_1'],
                    'otro_celular_2' => $perfil['otro_celular_2']
                ];

                $result = [
                    'token' => $token,
                    'refreshToken' => $refreshToken,
                    'user' => $userData,
                    'cursos' => $cursos
                ];

                $this->logger->info('Inicio de sesión exitoso', [
                    'username' => $username,
                    'user_id' => $user['id']
                ]);

                return $responseHelper->respondWithJson($result, 200, 'Inicio de sesión exitoso');

            } else {
                $this->logger->warning('Inicio de sesión fallido', [
                    'username' => $username,
                    'reason' => 'Credenciales inválidas'
                ]);
                return $responseHelper->respondWithError('Credenciales inválidas o usuario inactivo', 401);
            }
        } catch (PDOException $e) {
            $this->logger->error('Error en la consulta de base de datos', ['error' => $e->getMessage()]);
            return $responseHelper->respondWithError('Error en el servidor', 500);
        }
    }

    public function register(Request $request, Response $response): Response
    {
        $data = $request->getParsedBody();
        $responseHelper = new ResponseHelper($response);

        // Validación básica de datos
        $requiredFields = ['doctype_id', 'cedula', 'nombre', 'apellidos', 'fechanac', 'tel_celular', 'email', 'clave'];
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                return $responseHelper->respondWithError("El campo $field es requerido", 400);
            }
        }

        $this->db->beginTransaction();

        try {
            // 1. Insertar en personas.persons
            $sqlPerson = "INSERT INTO personas.persons (nombre, apellidos, fechanac, estado_civil, email, tel_celular) 
                          VALUES (:nombre, :apellidos, :fechanac, 5, :email, :tel_celular) RETURNING id";
            $stmtPerson = $this->db->prepare($sqlPerson);
            $stmtPerson->execute([
                'nombre' => $data['nombre'],
                'apellidos' => $data['apellidos'],
                'fechanac' => $data['fechanac'],
                'email' => $data['email'],
                'tel_celular' => $data['tel_celular']
            ]);
            $personId = $stmtPerson->fetchColumn();

            // 2. Insertar en inscripcion_alumnos.usuario
            $sqlUsuario = "INSERT INTO inscripcion_alumnos.usuario 
                           (id_person, id_estado, id_rol, email, clave, cedula, nombre, apellido, fechanac, doctype_id, active, actualizar_datos, tel_celular) 
                           VALUES (:id_person, 3, 3, :email, :clave, :cedula, :nombre, :apellido, :fechanac, :doctype_id, 0, 0, :tel_celular) RETURNING id";
            $stmtUsuario = $this->db->prepare($sqlUsuario);
            $stmtUsuario->execute([
                'id_person' => $personId,
                'email' => $data['email'],
                'clave' => $data['clave'],
                'cedula' => $data['cedula'],
                'nombre' => $data['nombre'],
                'apellido' => $data['apellidos'],
                'fechanac' => $data['fechanac'],
                'doctype_id' => $data['doctype_id'],
                'tel_celular' => $data['tel_celular']
            ]);
            $usuarioId = $stmtUsuario->fetchColumn();

            // 3. Insertar en personas.persons_docs
            $sqlPersonDocs = "INSERT INTO personas.persons_docs 
                              (doctype_id, person_id, valor, active, groupid) 
                              VALUES (:doctype_id, :person_id, :valor, 1, 1)";
            $stmtPersonDocs = $this->db->prepare($sqlPersonDocs);
            $stmtPersonDocs->execute([
                'doctype_id' => $data['doctype_id'],
                'person_id' => $personId,
                'valor' => $data['cedula']
            ]);

            // 4. Insertar en inscripcion_alumnos.alumno
            $sqlAlumno = "INSERT INTO inscripcion_alumnos.alumno 
                              (id_usuario, documento_identidad, datos_verificados, para_empleo) 
                              VALUES (:id_usuario, :documento_identidad, 2, f) RETURNING id";
            $stmtAlumno = $this->db->prepare($sqlAlumno);
            $stmtAlumno->execute([
                'id_usuario' => $usuarioId,
                'documento_identidad' => $data['cedula']
            ]);
            $alumnoId = $stmtAlumno->fetchColumn();

            // 5. Insertar en estadisticas.datos_personales
            $sqlDatosPersonales = "INSERT INTO estadisticas.datos_personales 
                              (id_alumno, cant_hijos, hijos) 
                              VALUES (:id_alumno, 0, 6) RETURNING id";
            $stmtDatosPersonales = $this->db->prepare($sqlDatosPersonales);
            $stmtDatosPersonales->execute([
                'id_alumno' => $alumnoId
            ]);
            $datosPersonalesId = $stmtDatosPersonales->fetchColumn();

            // 6. Insertar en estadisticas.alumnos_datos
            $sqlDatosPersonales = "INSERT INTO estadisticas.alumnos_datos
                              (id_datos_per) 
                              VALUES (:id_datos_per)";
            $stmtDatosPersonales = $this->db->prepare($sqlDatosPersonales);
            $stmtDatosPersonales->execute([
                'id_datos_per' => $datosPersonalesId
            ]);

            $this->db->commit();
            $this->logger->info("Nuevo usuario registrado", ['email' => $data['email']]);

            return $responseHelper->respondWithJson(['id' => $personId], 201, 'Usuario registrado exitosamente');

        } catch (PDOException $e) {
            $this->db->rollBack();
            $this->logger->error("Error en el registro de usuario", ['error' => $e->getMessage()]);
            return $responseHelper->respondWithError('Error en el registro de usuario', 500);
        }
    }

    public function refreshToken(Request $request, Response $response): Response
    {
        $responseHelper = new ResponseHelper($response);
        
        try {
            $token = $request->getHeaderLine('Authorization');
            
            if (empty($token)) {
                return $responseHelper->respondWithError('Token no proporcionado', 401);
            }

            $token = str_replace('Bearer ', '', $token);

            try {
                $decoded = JWT::decode($token, new Key($this->config['jwt_secret'], 'HS256'));
            } catch (\Exception $e) {
                return $responseHelper->respondWithError('Token inválido', 401);
            }

            $userId = $decoded->userId;
            $userIdPerson = $decoded->userIdPerson;

            // Verificar si el usuario sigue existiendo y está activo
            $stmt = $this->db->prepare("
                SELECT id, id_person, active
                FROM inscripcion_alumnos.usuario
                WHERE id = :id AND active = 1
            ");
            $stmt->execute(['id' => $userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                return $responseHelper->respondWithError('Usuario no encontrado o inactivo', 401);
            }

            // Generar un nuevo token
            $newToken = $this->generarToken($userId, $userIdPerson);

            $this->logger->info('Token refrescado exitosamente', [
                'user_id' => $userId
            ]);

            return $responseHelper->respondWithJson(['token' => $newToken], 200, 'Token refrescado exitosamente');

        } catch (PDOException $e) {
            $this->logger->error('Error en la consulta de base de datos', ['error' => $e->getMessage()]);
            return $responseHelper->respondWithError('Error en el servidor', 500);
        }
    }

    private function generarToken(string $userId, string $userIdPerson): string
    {
        $issuedAt = time();
        $expire = $issuedAt + 3600; // El token expira en 1 hora

        $payload = [
            'iat' => $issuedAt,
            'exp' => $expire,
            'userId' => $userId,
            'userIdPerson' => $userIdPerson
        ];

        return JWT::encode($payload, $this->config['jwt_secret'], 'HS256');
    }

    private function generarRefreshToken(string $userId, string $userIdPerson): string
    {
        $issuedAt = time();
        $expire = $issuedAt + (30 * 24 * 60 * 60); // El refresh token expira en 30 días

        $payload = [
            'iat' => $issuedAt,
            'exp' => $expire,
            'userId' => $userId,
            'userIdPerson' => $userIdPerson,
            'type' => 'refresh'
        ];

        return JWT::encode($payload, $this->config['jwt_refresh_secret'], 'HS256');
    }

}
