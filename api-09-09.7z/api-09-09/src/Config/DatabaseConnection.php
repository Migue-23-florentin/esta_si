<?php

namespace App\Config;

use PDO;
use PDOException;
use Monolog\Logger;

class DatabaseConnection
{
    private static $instance = null;
    private $pdo;
    private $logger;

    private function __construct(array $config, Logger $logger)
    {
        $this->logger = $logger;
        $this->connect($config);
    }

    public static function getInstance(array $config, Logger $logger): self
    {
        if (self::$instance === null) {
            self::$instance = new self($config, $logger);
        }
        return self::$instance;
    }

    private function connect(array $config): void
    {
        try {
            $dsn = "pgsql:host={$config['pgsql']['server']};port={$config['pgsql']['port']};dbname={$config['pgsql']['db']};";
            $this->pdo = new PDO($dsn, $config['pgsql']['user'], $config['pgsql']['password']);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            $this->logger->error('Error de conexión a la base de datos: ' . $e->getMessage());
            throw new \Exception('Error de conexión a la base de datos');
        }
    }

    public function getConnection(): PDO
    {
        return $this->pdo;
    }
}